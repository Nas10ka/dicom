# dicom
.idea
